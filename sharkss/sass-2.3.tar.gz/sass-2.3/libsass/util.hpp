#ifndef SASS_UTIL 
#define SASS_UTIL
#include <string>
namespace Sass {
  namespace Util {
    std::string normalize_underscores(const std::string& str);
  }
}
#endif